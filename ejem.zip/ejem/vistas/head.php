<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>conecta a los estudiantes</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="../script/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../script/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
     <!-- NAV -->
 <nav class="#0288d1 light-blue darken-2" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo white-text center">UIP</a>
    </div>
  </nav>
