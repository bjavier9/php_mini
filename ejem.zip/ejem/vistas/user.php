  <div class="container">
    <div class="section center">
        <div class="row">
            <form class="col s12" method="post">
              <div class="row">

                <div class="input-field col s4">
                  <i class="material-icons prefix">account_circle</i>
                  <input id="icon_prefix" type="text" class="validate" name="nom_u">
                  <label for="icon_prefix">Usuario</label>
                </div>

                <div class="input-field col s4">
                  <i class="material-icons prefix">lock</i>
                  <input id="icon_telephone" type="password" class="validate" name="contr_u">
                  <label for="icon_telephone">Contraseña</label>
                </div>
                <div class="input-field col s3">
                <a class="btn-floating btn-flat light-blue darken-2  pulse" name="btnlogin"><i class="material-icons">send</i></a>
                </div>
              </div>
            </form>
          </div>
                