
<?php 
require __DIR__ . '/lib/library.php';
include 'core/core.php';
include 'vistas/head.php';
include 'vistas/user.php';
$sql= "SELECT * FROM estudiantes"
?>




<?php 
include 'vistas/footer.php';
?>
