<?php


define('HOST', 'sql9.freemysqlhosting.net'); // Database host name ex. localhost
define('USER', 'GqLxsFZ1ms'); // Database user. ex. root ( if your on local server)
define('PASSWORD', ''); // user password  (if password is not set for user then keep it empty )
define('DATABASE', 'sql9258496'); // Database Database name


class Conexion
{

    private static $instancia;
    private $dbh;

    private function __construct()
    {
        try {

            $this->dbh = new PDO('mysql:host=' . HOST . ';dbname=' . DATABASE . '', USER, PASSWORD);
            $this->dbh->exec("SET CHARACTER SET utf8");

        } catch (PDOException $e) {

            print "Error!: " . $e->getMessage();

            die();
        }
    }

    public function prepare($sql)
    {

        return $this->dbh->prepare($sql);

    }

    public static function singleton_conexion()
    {

        if (!isset(self::$instancia)) {
            $miclase = __class__;
            self::$instancia = new $miclase;

        }

        return self::$instancia;

    }
 
 
     // Evita que el objeto se pueda clonar
    public function __clone()
    {

        trigger_error('La clonación de este objeto no está permitida', E_USER_ERROR);

    }
}

?>


