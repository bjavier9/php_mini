<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="XS landing - Multipurpose Extra Small Landing Template">
    <meta name="author" content="forbetterweb.com">

    <title>Portal Laureate Panam&aacute;</title>

    <!-- Bootstrap Core CSS -->
    <link href="../script/css/bootstrap.min.css" rel="stylesheet">
     <!-- Compiled and minified CSS -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">


        <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> -->

    <!-- Custom fonts -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="../script/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="../script/css/ionicons.min.css" rel="stylesheet" type="text/css">
    <!-- materialcss -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://material-components.github.io/material-components-web-catalog/static/css/main.02c3a30d.css">

    <!-- Custom CSS -->
    <link href="../script/js/vegas/vegas.min.css" rel="stylesheet" type="text/css">
    <link href="../script/css/animate.min.css" rel="stylesheet" type="text/css">
    <link href="../script/css/xslanding.css" rel="stylesheet">

        <!--favicon-->
        <link rel="apple-touch-icon" sizes="57x57" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://www.uip.edu.pa/wp-content/themes/uip/images/favicon/favicon-16x16.png">


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>

<body class="wow fadeIn">