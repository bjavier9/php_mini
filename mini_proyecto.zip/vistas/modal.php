<div class="about-modal modal fade" id="aboutModal1" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content text-center">
            <div class="close-modal" data-dismiss="modal">
                <i class="icon ion-ios-close-empty"></i>
            </div>
            <div id="about" class="container wow fadeIn animated">
                <div class="row">
                    <div class="col-md-12">
                        <img src="http://portal.uip.edu.pa/resources/images/institutions/banner_uip.png" width="300" alt="banner">
                        <h3>Lorem Ipsum Lorem Ipsum</h3>
                        <hr>
                        <p>Lorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem IpsumLorem Ipsum Lorem Ipsum Lorem IpsumLorem IpsumLorem Ipsum.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6 wow fadeIn animated" data-wow-delay=".2s">
                        <h4><i class="icon ion-ios-infinite-outline" data-wow-duration="7s" data-wow-delay=".7s"></i>
                            <img src="img/cuadro.jpg" class="img-responsive img-centered" alt="">
                            Lorem Ipsum</h4>
                        <p>Lorem ipsum dolor sit amet consecte tur adipiscingtitor diam</p>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeIn animated" data-wow-delay=".4s">
                        <h4><i class="icon ion-ios-stopwatch-outline"></i>
                            <img src="img/cuadro.jpg" class="img-responsive img-centered" alt="">
                            Lorem Ipsum</h4>
                        <p>Lorem ipsum dolor sit amet consecte tur adipiscingtitor diam</p>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeIn animated" data-wow-delay=".6s">
                        <h4><i class="icon ion-ios-monitor-outline"></i>
                            <img src="img/cuadro.jpg" class="img-responsive img-centered" alt="">
                            Lorem Ipsum</h4>
                        <p>Lorem ipsum dolor sit amet consecte tur adipiscingtitor diam</p>
                    </div>
                    <div class="col-md-3 col-sm-6 wow fadeIn animated" data-wow-delay=".8s">
                        <h4><i class="icon ion-ios-settings"></i>
                            <img src="img/cuadro.jpg" class="img-responsive img-centered" alt="">
                            Lorem Ipsum</h4>
                        <p>Lorem ipsum dolor sit amet consecte tur adipiscingtitor diam</p>
                    </div>
                </div>
            </div>
            <button type="button" class="btn btn-dark btn-lg" data-dismiss="modal">CLOSE</button>
        </div>
    </div>
</div>