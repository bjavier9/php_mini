
<!-- jQuery -->
<script src="../script/js/jquery.js"></script>


<!-- Plugin JavaScript -->
<script src="../script/js/device.min.js"></script>
<script src="../script/js/wow.min.js"></script>
<script src="../script/js/smoothscroll.js"></script>

<!-- Contact Form -->
<script src="../script/js/form.js"></script>
<script src="../script/js/jquery.placeholder.min.js"></script>

<!-- Background Slider -->
<script src="../script/js/vegas/vegas.min.js"></script>
<script>
    $('body').vegas({
        delay: 10000,
        timer: false,
        transitionDuration: 2000,
        slides: [
            { src: '../media/img/uip/Campus_UIP.jpeg' },
            { src: '../media/img/uip/Alfombras-BOLYU-2.jpeg' },
            { src: '../media/img/uip/IMG-20150820-WA0016.jpg' }
        ],
        transition: 'swirlRight',
        animation: 'kenburns'
    });
</script>
<!-- material script -->


<!-- Custom Theme JavaScript -->
<script src="../script/js/xslanding.js"></script>
<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>


<!-- Demo Switcher / For Demonstration Purposes Only
<div class="demo-switcher"><script src="js/demo-switcher.js"></script></div> -->

</body>


</html>