<!-- <form name="sentMessage" id="contactForm" novalidate autocomplete="off" >

 <div class="row">
      <form class="col s12" id="contacForm" novalidate>
        <div class="row">
          <div class="input-field col s12">
            <input id="name" type="text" data-length="10" required data-validation-required-message="Introducir usuario">
            <label for="name">usuario</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
          <input id="password" type="text" data-length="10" required data-validation-required-message="Introducir usuario">
            <label for="password">password</label>
            <button class="btn waves-effect waves-light #1e88e5 blue darken-1 text-white" type="submit">Acceder</button>
          </div>
        </div>
      </form>
    </div> -->
        <form name="sentMessage" id="contactForm" novalidate autocomplete="off">

                                <div class="control-group ">
                                    <div class="form-group floating-label-form-group controls">
                                    
                                        <input type="text" class="form-control input-lg text-black" placeholder="Usuario" id="name" required data-validation-required-message="Introducir usuario">
                                        
                                        <span class="help-block text-danger"></span>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <div class="form-group floating-label-form-group controls">
                                        <div class="input-group input-group-lg">
                                        
                                            <input type="password" class="form-control input-lg input-group-lg" placeholder="Contrase&ntilde;a" id="contrasena" required data-validation-required-message="Introducir contrase&ntilde;a">
                                            <div class="input-group-btn">
                                                <button type="submit" class="btn btn-primary btn-sm  waves-effect waves-light #0277bd light-blue darken-3 ">ACCEDER</button>
                                            </div>
                                        </div>
                                        <span class="help-block text-danger"></span>
                                    </div>
                                </div>
                                <div id="success"></div>
                            </form>
                            <a href="https://www.facebook.com/uippanama" class="btn-floating btn-large waves-effect waves-light #0277bd light-blue darken-3 pulse"><i class="fa fa-facebook fa-fw fa-2x"></i></a>
                            <a href="https://twitter.com/uippanama" class="btn-floating btn-large waves-effect waves-light #0277bd light-blue darken-3 pulse"><i class="fa fa-twitter fa-fw fa-2x"></i></a>
                            <a href="https://www.linkedin.com/school/311192?pathWildcard=311192" class="btn-floating btn-large waves-effect waves-light #0277bd light-blue darken-3 pulse"><i class="fa fa-linkedin fa-fw fa-2x"></i></a>
                            <p></p>
                            <p><img src="../media/img/liu-vert_500.png" alt="banner">

                            
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

