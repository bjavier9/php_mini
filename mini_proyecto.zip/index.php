

<!-- inicia el head --><?php
                        include 'vistas/head.php';

                        ?>

    <!-- termina el head ###################################-->

<div class="overlay"></div>

<div class="container-fluid content">
    <div class="row content">
        <div class="col-md-9 promo">
            <div class="row intropromo">
                   <!-- <div class="col-sm-6">
                        <h2 class="wow bounceInDown">I Like To Move It</h2>
                    </div>-->
                    <div class="col-sm-6">
                      <!--  <h4>Bienvenido al Portal de Servicios Centralizados de Laureate Panamá</h4>
                      <i class="icon iconbig ion-ios-information-outline"></i>
                      -->
                        <p><i ></i>Bienvenido al Portal de Servicios Centralizados de Laureate Panamá.</p>
                        <div class="row">
  <div class="col"><button class="mdc-fab  demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Suscribete</span></button></div>
  <div class="col"><button class="mdc-fab  demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Suscribete</span></button></div>
  <div class="col"><button class="mdc-fab  demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Suscribete</span></button></div>
  <div class="col"><button class="mdc-fab  demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Suscribete</span></button></div>
</div>

                        <ul class="list-inline lead">
                            <li><</li>
                            <li><button class="mdc-fab demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Olvidaste tu clave?</span></button></li>
                            <li><button class="mdc-fab demo-fab-shaped--three mdc-fab--extended mdc-ripple-upgraded waves-effect waves-light #0277bd light-blue darken-3 " aria-label="Favorite"><span class="mdc-fab__label">Más Información</span></button></li>
                            
                        </ul>
                    </div>
            </div>
        </div>
        <div class="col-md-3 col-left no-pad">
            <div class="leftline wow fadeInLeft">
                <div class="leftlineinside">
                    <div class="row">
                        <div class="col-md-12 col-sm-6">
                            <h1 class="logo"><img src="../media/img/logo.png" width="400" alt="Logo" class="img-responsive"></h1>
                        </div>
                        <div class="col-md-12 col-sm-6">
                           <!-- <h2 class="red">Bienvenido al Portal de Servicios Centralizados de Laureate Panamá</h2>-->
                            <p class="text-justify">Laureate International Universities Panamá les da la bienvenida al portal de acceso, cuyo objetivo es permitir de manera más efectiva a los estudiantes y profesores utilizar los diferentes servicios por la Universidad.</p>
                            <!-- Contact Form - Enter your email address on line 17 of the mail/contact_me.php file to make this form work. -->
                            <!-- WARNING: Some web hosts do not allow emails to be sent through forms to common mail hosts like Gmail or Yahoo. It's recommended that you use a private domain email address! -->
                            <!-- NOTE: To use the contact form, your site must be on a live web host with PHP! The form will not work locally! -->
                           


<!-- modal de informacion -->
<?php 
include 'vistas/login.php';
include 'vistas/modal.php';
include 'vistas/footer.php';
?>
<!-- termina modal -->





<!-- footer -->

<!-- termina el footer -->